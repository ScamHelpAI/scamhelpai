(() => {
  // src/content/page/read-page.ts
  var SKIP_TAGS = /* @__PURE__ */ new Set([
    "SCRIPT",
    "STYLE",
    "NOSCRIPT",
    "TEMPLATE",
    "SVG",
    "CANVAS",
    "IFRAME",
    "OBJECT",
    "EMBED"
  ]);
  function isNoiseElement(el) {
    const tag = el.tagName;
    if (tag === "NAV" || tag === "FOOTER" || tag === "ASIDE") return true;
    const role = el.getAttribute("role")?.toLowerCase() ?? "";
    if (role === "navigation" || role === "contentinfo" || role === "banner") {
      return true;
    }
    const hint = `${el.className} ${el.id}`.toLowerCase();
    return /\b(nav|navbar|footer|cookie|consent|sidebar|menu|advert|ads?)\b/.test(
      hint
    );
  }
  function selectPageRoot(doc) {
    return doc.querySelector("main") ?? doc.querySelector("article") ?? doc.body ?? doc.documentElement;
  }
  function cleanClone(root) {
    const clone = root.cloneNode(true);
    for (const el of [...clone.querySelectorAll("*")]) {
      if (SKIP_TAGS.has(el.tagName) || isNoiseElement(el)) {
        el.remove();
      }
    }
    return clone;
  }
  function readPageContents(doc = document) {
    const root = selectPageRoot(doc);
    const cleaned = cleanClone(root);
    return {
      url: doc.location?.href ?? "",
      title: doc.title.trim(),
      html: cleaned.outerHTML.trim()
    };
  }

  // src/content/page/index.ts
  var INSTALLED_FLAG = "__scamhelpPageReaderInstalled";
  var pageWindow = window;
  if (!pageWindow[INSTALLED_FLAG]) {
    pageWindow[INSTALLED_FLAG] = true;
    chrome.runtime.onMessage.addListener(
      (message, _sender, sendResponse) => {
        if (message?.type !== "readPageContents") return false;
        try {
          const page = readPageContents(document);
          const response = {
            ok: true,
            url: page.url,
            title: page.title,
            html: page.html
          };
          sendResponse(response);
        } catch (error) {
          const response = {
            ok: false,
            error: error instanceof Error ? error.message : "Could not read this page."
          };
          sendResponse(response);
        }
        return false;
      }
    );
  }
})();
