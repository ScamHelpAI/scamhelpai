(() => {
  // src/shared/check.ts
  var CHECK_URLS_BATCH_SIZE = 100;
  function chunkUrls(urls, size) {
    if (size <= 0) return [urls];
    const chunks = [];
    for (let i = 0; i < urls.length; i += size) {
      chunks.push(urls.slice(i, i + size));
    }
    return chunks;
  }

  // src/shared/settings.ts
  var LINK_SCAN_ENABLED_KEY = "linkScanEnabled";
  async function getLinkScanEnabled() {
    const stored = await chrome.storage.sync.get(LINK_SCAN_ENABLED_KEY);
    return stored[LINK_SCAN_ENABLED_KEY] === true;
  }

  // src/shared/font-family.ts
  var FONT_FAMILY = '"Atkinson Hyperlegible Next", system-ui, -apple-system, "Segoe UI", sans-serif';

  // src/shared/risk-icon-svgs.ts
  var RISK_COLORS = {
    high: "#b3261e",
    medium: "#6b4200",
    low: "#1e6b34"
  };
  var TRIANGLE_ALERT_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>`;
  var OCTAGON_ALERT_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.25" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 16h.01"/><path d="M12 8v4"/><path d="M15.312 2a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586l-4.688-4.688A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2z"/></svg>`;

  // src/content/links/decorate.ts
  var SCAMHELP_MARK = "data-scamhelp";
  var SCAMHELP_STATUS = "data-scamhelp-status";
  var SCAMHELP_HREF = "data-scamhelp-href";
  var SCAMHELP_BLOCKED = "data-scamhelp-blocked";
  var STYLE_ID = "scamhelp-link-scan-styles";
  function ensureStyles(doc = document) {
    if (doc.getElementById(STYLE_ID)) return;
    const style = doc.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
    a[${SCAMHELP_STATUS}="warning"] {
      text-decoration-line: underline !important;
      text-decoration-color: ${RISK_COLORS.medium} !important;
      text-decoration-thickness: 2px !important;
      text-underline-offset: 2px;
    }
    [${SCAMHELP_MARK}="icon"] {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      margin-left: 0.35em;
      width: 1.35em;
      height: 1.35em;
      line-height: 1;
      vertical-align: middle;
      cursor: default;
      user-select: none;
      border: none;
      border-radius: 0.35em;
      background: transparent;
      padding: 0;
      font-family: inherit;
    }
    [${SCAMHELP_MARK}="icon"] svg {
      display: block;
      width: 1em;
      height: 1em;
    }
    [${SCAMHELP_MARK}="icon"][${SCAMHELP_STATUS}="warning"] {
      color: ${RISK_COLORS.medium};
      background: #fff3e0;
    }
    [${SCAMHELP_MARK}="icon"][${SCAMHELP_STATUS}="danger"] {
      color: ${RISK_COLORS.high};
      background: #fbe9e7;
      cursor: pointer;
    }
    [${SCAMHELP_BLOCKED}="1"] {
      display: inline;
      color: inherit;
    }
    [${SCAMHELP_MARK}="popover"] {
      position: absolute;
      z-index: 2147483646;
      max-width: 280px;
      margin-top: 4px;
      padding: 10px 12px;
      border: 2px solid ${RISK_COLORS.high};
      border-radius: 12px;
      background: #fff;
      color: #111;
      font: 13px/1.4 ${FONT_FAMILY};
      box-shadow: 0 8px 24px rgba(0,0,0,0.18);
    }
    [${SCAMHELP_MARK}="popover"] strong {
      display: block;
      margin-bottom: 6px;
      font-size: 14px;
    }
    [${SCAMHELP_MARK}="popover"] ul {
      margin: 0 0 10px;
      padding-left: 1.1em;
    }
    [${SCAMHELP_MARK}="popover"] button[data-action="open"] {
      display: inline-block;
      padding: 6px 10px;
      border: none;
      border-radius: 6px;
      background: ${RISK_COLORS.high};
      color: #fff;
      font: 600 13px/1.2 ${FONT_FAMILY};
      cursor: pointer;
    }
    [${SCAMHELP_MARK}="popover"] button[data-action="close"] {
      display: inline-block;
      margin-left: 8px;
      padding: 6px 10px;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
      background: #fff;
      color: #334155;
      font: 600 13px/1.2 ${FONT_FAMILY};
      cursor: pointer;
    }
  `;
    doc.documentElement.appendChild(style);
  }
  function removeStyles(doc = document) {
    doc.getElementById(STYLE_ID)?.remove();
    closePopover(doc);
  }
  function closePopover(doc = document) {
    for (const node of doc.querySelectorAll(`[${SCAMHELP_MARK}="popover"]`)) {
      node.remove();
    }
  }
  function createIcon(doc, status, title) {
    const isButton = status === "danger";
    const el = doc.createElement(isButton ? "button" : "span");
    el.setAttribute(SCAMHELP_MARK, "icon");
    el.setAttribute(SCAMHELP_STATUS, status);
    el.setAttribute("title", title);
    el.setAttribute(
      "aria-label",
      status === "warning" ? "Caution: this link may be risky" : "Blocked unsafe link"
    );
    if (isButton) {
      el.type = "button";
    }
    el.innerHTML = status === "warning" ? TRIANGLE_ALERT_SVG : OCTAGON_ALERT_SVG;
    return el;
  }
  function reasonSummary(result) {
    return result.reasons[0] ?? `Risk score ${result.score}`;
  }
  function showDangerPopover(anchorHost, result, href, doc = document) {
    closePopover(doc);
    const pop = doc.createElement("div");
    pop.setAttribute(SCAMHELP_MARK, "popover");
    pop.setAttribute("role", "dialog");
    const title = doc.createElement("strong");
    title.textContent = "Unsafe link blocked";
    pop.appendChild(title);
    const list = doc.createElement("ul");
    for (const reason of result.reasons.slice(0, 4)) {
      const item = doc.createElement("li");
      item.textContent = reason;
      list.appendChild(item);
    }
    if (result.reasons.length === 0) {
      const item = doc.createElement("li");
      item.textContent = `Risk score ${result.score} out of 100.`;
      list.appendChild(item);
    }
    pop.appendChild(list);
    const openBtn = doc.createElement("button");
    openBtn.type = "button";
    openBtn.dataset.action = "open";
    openBtn.textContent = "Open anyway";
    openBtn.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      closePopover(doc);
      window.location.assign(href);
    });
    pop.appendChild(openBtn);
    const closeBtn = doc.createElement("button");
    closeBtn.type = "button";
    closeBtn.dataset.action = "close";
    closeBtn.textContent = "Close";
    closeBtn.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      closePopover(doc);
    });
    pop.appendChild(closeBtn);
    const rect = anchorHost.getBoundingClientRect();
    pop.style.position = "fixed";
    pop.style.left = `${Math.max(8, rect.left)}px`;
    pop.style.top = `${Math.min(window.innerHeight - 8, rect.bottom + 4)}px`;
    doc.documentElement.appendChild(pop);
  }
  function isScamhelpNode(node) {
    if (!(node instanceof Element)) return false;
    return node.hasAttribute(SCAMHELP_MARK) || node.hasAttribute(SCAMHELP_BLOCKED) || node.hasAttribute(SCAMHELP_STATUS) || Boolean(node.closest(`[${SCAMHELP_MARK}], [${SCAMHELP_BLOCKED}]`));
  }
  function clearDecorations(root = document) {
    const doc = root instanceof Document ? root : root.ownerDocument ?? document;
    closePopover(doc);
    for (const icon of root.querySelectorAll(`[${SCAMHELP_MARK}="icon"]`)) {
      icon.remove();
    }
    for (const blocked of [
      ...root.querySelectorAll(`[${SCAMHELP_BLOCKED}="1"]`)
    ]) {
      const href = blocked.getAttribute(SCAMHELP_HREF);
      if (!href || !(blocked instanceof HTMLElement)) {
        blocked.removeAttribute(SCAMHELP_BLOCKED);
        blocked.removeAttribute(SCAMHELP_HREF);
        blocked.removeAttribute(SCAMHELP_MARK);
        continue;
      }
      const anchor = doc.createElement("a");
      anchor.href = href;
      while (blocked.firstChild) {
        const child = blocked.firstChild;
        if (child instanceof Element && child.getAttribute(SCAMHELP_MARK) === "icon") {
          child.remove();
          continue;
        }
        anchor.appendChild(child);
      }
      blocked.replaceWith(anchor);
    }
    for (const link of root.querySelectorAll(`a[${SCAMHELP_STATUS}]`)) {
      link.removeAttribute(SCAMHELP_STATUS);
      link.removeAttribute(SCAMHELP_MARK);
    }
  }
  function decorateAnchor(anchor, result, doc = document) {
    if (anchor.getAttribute(SCAMHELP_STATUS) === result.status) {
      return;
    }
    const existingIcon = anchor.parentElement?.querySelector(
      `:scope > [${SCAMHELP_MARK}="icon"]`
    );
    const nextSibling = anchor.nextElementSibling;
    if (nextSibling?.getAttribute(SCAMHELP_MARK) === "icon") {
      nextSibling.remove();
    }
    if (existingIcon && existingIcon !== nextSibling) {
      existingIcon.remove();
    }
    if (result.status === "safe") {
      anchor.setAttribute(SCAMHELP_STATUS, "safe");
      anchor.setAttribute(SCAMHELP_MARK, "link");
      return;
    }
    if (result.status === "danger") {
      const href = result.url;
      const wrapper = doc.createElement("span");
      wrapper.setAttribute(SCAMHELP_BLOCKED, "1");
      wrapper.setAttribute(SCAMHELP_HREF, href);
      wrapper.setAttribute(SCAMHELP_MARK, "blocked");
      while (anchor.firstChild) {
        wrapper.appendChild(anchor.firstChild);
      }
      if (!wrapper.textContent?.trim() && anchor.textContent) {
        wrapper.append(anchor.textContent);
      }
      const icon2 = createIcon(doc, "danger", reasonSummary(result));
      icon2.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        showDangerPopover(wrapper, result, href, doc);
      });
      wrapper.appendChild(icon2);
      anchor.replaceWith(wrapper);
      return;
    }
    anchor.setAttribute(SCAMHELP_STATUS, result.status);
    anchor.setAttribute(SCAMHELP_MARK, "link");
    const icon = createIcon(doc, result.status, reasonSummary(result));
    anchor.insertAdjacentElement("afterend", icon);
  }

  // src/content/links/urls.ts
  function normalizeHttpUrl(href) {
    try {
      const url = new URL(href);
      if (url.protocol !== "http:" && url.protocol !== "https:") {
        return null;
      }
      return url.toString();
    } catch {
      return null;
    }
  }
  function resolveAnchorUrl(anchor, baseHref = location.href) {
    const raw = anchor.getAttribute("href");
    if (raw === null || raw.trim() === "") return null;
    try {
      return normalizeHttpUrl(new URL(raw, baseHref).toString());
    } catch {
      return null;
    }
  }

  // src/content/links/index.ts
  var INSTALLED_FLAG = "__scamhelpLinkScannerInstalled";
  var resultCache = /* @__PURE__ */ new Map();
  var inFlight = /* @__PURE__ */ new Set();
  var enabled = false;
  var observer = null;
  var scanTimer = null;
  var scanning = false;
  async function requestChecks(urls) {
    if (urls.length === 0) return [];
    const response = await chrome.runtime.sendMessage({
      type: "checkUrls",
      urls
    });
    if (!response?.ok) {
      throw new Error(
        response && "error" in response ? response.error : "Could not check links."
      );
    }
    return response.results;
  }
  function collectUncheckedAnchors(root = document) {
    const anchors = [];
    const urlSet = /* @__PURE__ */ new Set();
    for (const node of root.querySelectorAll("a[href]")) {
      if (!(node instanceof HTMLAnchorElement)) continue;
      if (isScamhelpNode(node) && node.hasAttribute("data-scamhelp-status")) {
        continue;
      }
      if (node.closest("[data-scamhelp-blocked]")) continue;
      const url = resolveAnchorUrl(node);
      if (!url) continue;
      if (resultCache.has(url)) {
        anchors.push(node);
        continue;
      }
      if (inFlight.has(url)) {
        anchors.push(node);
        continue;
      }
      anchors.push(node);
      urlSet.add(url);
    }
    return { anchors, urls: [...urlSet] };
  }
  function applyCachedResults(anchors) {
    for (const anchor of anchors) {
      const url = resolveAnchorUrl(anchor);
      if (!url) continue;
      const result = resultCache.get(url);
      if (!result) continue;
      if (anchor.isConnected) {
        decorateAnchor(anchor, result);
      }
    }
  }
  async function scanLinks(root = document) {
    if (!enabled) return;
    if (scanning) {
      scheduleScan(root);
      return;
    }
    scanning = true;
    try {
      ensureStyles();
      const { anchors, urls } = collectUncheckedAnchors(root);
      applyCachedResults(anchors);
      const missing = urls.filter((url) => !resultCache.has(url));
      for (const url of missing) inFlight.add(url);
      try {
        for (const batch of chunkUrls(missing, CHECK_URLS_BATCH_SIZE)) {
          if (!enabled) break;
          const results = await requestChecks(batch);
          for (const result of results) {
            resultCache.set(result.url, result);
            inFlight.delete(result.url);
          }
          for (const url of batch) {
            inFlight.delete(url);
            if (!resultCache.has(url)) {
              const match = results.find((r) => r.url === url);
              if (match) resultCache.set(url, match);
            }
          }
        }
      } finally {
        for (const url of missing) inFlight.delete(url);
      }
      if (enabled) {
        const again = collectUncheckedAnchors(document);
        applyCachedResults(again.anchors);
      }
    } catch (error) {
      console.warn("[ScamHelp] link scan failed:", error);
    } finally {
      scanning = false;
    }
  }
  function scheduleScan(root = document) {
    if (scanTimer !== null) {
      window.clearTimeout(scanTimer);
    }
    scanTimer = window.setTimeout(() => {
      scanTimer = null;
      void scanLinks(root);
    }, 250);
  }
  function startObserver() {
    if (observer) return;
    observer = new MutationObserver((mutations) => {
      if (!enabled) return;
      for (const mutation of mutations) {
        if (mutation.type === "attributes" && mutation.target instanceof Element) {
          if (mutation.target.tagName === "A" && !isScamhelpNode(mutation.target)) {
            scheduleScan(document);
            return;
          }
        }
        for (const node of mutation.addedNodes) {
          if (isScamhelpNode(node)) continue;
          if (node instanceof HTMLAnchorElement) {
            scheduleScan(document);
            return;
          }
          if (node instanceof Element && node.querySelector?.("a[href]")) {
            scheduleScan(document);
            return;
          }
        }
      }
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["href"]
    });
  }
  function stopObserver() {
    observer?.disconnect();
    observer = null;
  }
  async function enableScanning() {
    enabled = true;
    ensureStyles();
    startObserver();
    await scanLinks(document);
  }
  function disableScanning() {
    enabled = false;
    stopObserver();
    if (scanTimer !== null) {
      window.clearTimeout(scanTimer);
      scanTimer = null;
    }
    clearDecorations(document);
    removeStyles();
  }
  var pageWindow = window;
  if (!pageWindow[INSTALLED_FLAG]) {
    pageWindow[INSTALLED_FLAG] = true;
    void getLinkScanEnabled().then((on) => {
      if (on) void enableScanning();
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "sync" || !(LINK_SCAN_ENABLED_KEY in changes)) return;
      const next = changes[LINK_SCAN_ENABLED_KEY]?.newValue === true;
      if (next) {
        void enableScanning();
      } else {
        disableScanning();
      }
    });
  }
})();
