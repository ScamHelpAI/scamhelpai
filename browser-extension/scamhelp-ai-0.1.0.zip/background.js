// src/shared/api-url.ts
var DEFAULT_API_BASE = "https://api.scamhelp.ai";
function analysesUrl(apiBase) {
  return `${apiBase.replace(/\/+$/, "")}/v1/analyses`;
}
function analysisUrl(apiBase, id) {
  return `${analysesUrl(apiBase)}/${id}`;
}
function checkUrlsUrl(apiBase) {
  return `${apiBase.replace(/\/+$/, "")}/v1/check/urls`;
}
function analyzerErrorMessage(status, bodyText) {
  if (status === 0) {
    return "Could not reach the ScamHelp server. Is it running?";
  }
  if (bodyText.trim()) {
    try {
      const parsed = JSON.parse(bodyText);
      if (typeof parsed.message === "string" && parsed.message) {
        return parsed.message;
      }
      if (typeof parsed.error === "string" && parsed.error) {
        return parsed.error;
      }
    } catch {
    }
  }
  return `Analyzer returned ${status}.`;
}

// src/shared/check.ts
var CHECK_URLS_BATCH_SIZE = 100;
function chunkUrls(urls, size) {
  if (size <= 0) return [urls];
  const chunks = [];
  for (let i = 0; i < urls.length; i += size) {
    chunks.push(urls.slice(i, i + size));
  }
  return chunks;
}

// src/shared/page-request.ts
var MAX_HTML_CHARS = 2e4;
function pageHtmlToAnalyzeRequest(html, pageUrl) {
  const content = html.trim().slice(0, MAX_HTML_CHARS);
  if (!content) {
    throw new Error("This page had no readable content.");
  }
  return {
    inputs: [{ type: "text", content }],
    context: {
      source: "browser_extension",
      ...pageUrl ? { pageUrl } : {}
    }
  };
}

// src/shared/settings.ts
var LINK_SCAN_ENABLED_KEY = "linkScanEnabled";
var ALL_SITES = ["http://*/*", "https://*/*"];
async function getLinkScanEnabled() {
  const stored = await chrome.storage.sync.get(LINK_SCAN_ENABLED_KEY);
  return stored[LINK_SCAN_ENABLED_KEY] === true;
}
async function setLinkScanEnabled(enabled) {
  await chrome.storage.sync.set({ [LINK_SCAN_ENABLED_KEY]: enabled });
}

// src/background/index.ts
async function injectLinkScannerIntoOpenTabs() {
  const tabs = await chrome.tabs.query({ url: ["http://*/*", "https://*/*"] });
  await Promise.all(
    tabs.map(async (tab) => {
      if (tab.id === void 0) return;
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["content/links.js"]
        });
      } catch {
      }
    })
  );
}
var LINK_SCRIPT_ID = "links";
async function syncLinkScanner() {
  const enabled = await getLinkScanEnabled();
  const granted = await chrome.permissions.contains({ origins: ALL_SITES });
  if (enabled && !granted) {
    await setLinkScanEnabled(false);
    return;
  }
  const registered = await chrome.scripting.getRegisteredContentScripts({
    ids: [LINK_SCRIPT_ID]
  });
  if (enabled && registered.length === 0) {
    await chrome.scripting.registerContentScripts([
      {
        id: LINK_SCRIPT_ID,
        js: ["content/links.js"],
        matches: ALL_SITES,
        runAt: "document_idle"
      }
    ]);
    await injectLinkScannerIntoOpenTabs();
  } else if (!enabled && registered.length > 0) {
    await chrome.scripting.unregisterContentScripts({ ids: [LINK_SCRIPT_ID] });
  }
}
async function getApiBase() {
  const { apiBase } = await chrome.storage.sync.get("apiBase");
  return typeof apiBase === "string" && apiBase.length > 0 ? apiBase.replace(/\/+$/, "") : DEFAULT_API_BASE;
}
async function getActiveTab() {
  const [tab] = await chrome.tabs.query({
    active: true,
    currentWindow: true
  });
  if (!tab?.id) {
    throw new Error("No active tab found.");
  }
  if (!tab.url || !/^https?:/i.test(tab.url)) {
    throw new Error("Please go to a webpage first.");
  }
  return tab;
}
async function readActivePageContents() {
  const tab = await getActiveTab();
  const tabId = tab.id;
  if (tabId === void 0) {
    return { ok: false, error: "No active tab found." };
  }
  const request = { type: "readPageContents" };
  try {
    const response = await chrome.tabs.sendMessage(tabId, request);
    if (response) return response;
  } catch {
  }
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content/page.js"]
    });
    const response = await chrome.tabs.sendMessage(tabId, request);
    if (!response) {
      return { ok: false, error: "Page script did not respond." };
    }
    return response;
  } catch {
    return {
      ok: false,
      error: "Could not read this page. Try reloading the tab."
    };
  }
}
async function createAnalysis(request) {
  const res = await fetch(analysesUrl(await getApiBase()), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(request)
  });
  if (!res.ok) {
    const bodyText = await res.text().catch(() => "");
    throw new Error(analyzerErrorMessage(res.status, bodyText));
  }
  return res.json();
}
async function fetchAnalysis(id) {
  const res = await fetch(analysisUrl(await getApiBase(), id));
  if (!res.ok) {
    const bodyText = await res.text().catch(() => "");
    throw new Error(analyzerErrorMessage(res.status, bodyText));
  }
  return res.json();
}
async function applyPageAnnotations(message) {
  const tab = await getActiveTab();
  const tabId = tab.id;
  if (tabId === void 0) {
    return { ok: false, error: "No active tab found." };
  }
  try {
    const response = await chrome.tabs.sendMessage(tabId, message);
    if (response?.ok) return response;
  } catch {
  }
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content/annotations.js"]
    });
    const response = await chrome.tabs.sendMessage(tabId, message);
    if (!response?.ok) {
      return {
        ok: false,
        error: response?.error ?? "Annotation script did not respond."
      };
    }
    return response;
  } catch {
    return {
      ok: false,
      error: "Could not annotate this page. Try reloading the tab."
    };
  }
}
async function scanActivePage() {
  const page = await readActivePageContents();
  if (!page.ok) {
    throw new Error(page.error);
  }
  return createAnalysis(pageHtmlToAnalyzeRequest(page.html, page.url));
}
async function checkUrls(urls) {
  const unique = [...new Set(urls)];
  const apiBase = await getApiBase();
  const results = [];
  for (const batch of chunkUrls(unique, CHECK_URLS_BATCH_SIZE)) {
    const res = await fetch(checkUrlsUrl(apiBase), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        urls: batch,
        context: { source: "browser_extension" }
      })
    });
    if (!res.ok) {
      const bodyText = await res.text().catch(() => "");
      throw new Error(analyzerErrorMessage(res.status, bodyText));
    }
    const body = await res.json();
    results.push(...body.results);
  }
  return results;
}
var ANALYZE_EMAIL_MENU_ID = "scamhelp-analyze-email";
chrome.runtime.onInstalled.addListener(() => {
  void syncLinkScanner();
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: ANALYZE_EMAIL_MENU_ID,
      title: "Analyze Email",
      contexts: ["all"],
      documentUrlPatterns: ["https://mail.google.com/*"]
    });
  });
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== ANALYZE_EMAIL_MENU_ID || tab?.id === void 0) return;
  chrome.tabs.sendMessage(tab.id, {
    type: "analyzeOpenEmail"
  }).catch(() => {
  });
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "sync" || !(LINK_SCAN_ENABLED_KEY in changes)) return;
  void syncLinkScanner();
});
chrome.permissions.onRemoved.addListener(() => void syncLinkScanner());
chrome.runtime.onMessage.addListener(
  (message, _sender, sendResponse) => {
    if (message?.type === "readActivePage") {
      readActivePageContents().then((result) => sendResponse(result)).catch(
        (error) => sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Could not read this page."
        })
      );
      return true;
    }
    if (message?.type === "scanActivePage") {
      scanActivePage().then(
        (result) => sendResponse({ ok: true, result })
      ).catch(
        (error) => sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Is the ScamHelp server running?"
        })
      );
      return true;
    }
    if (message?.type === "getAnalysis") {
      fetchAnalysis(message.id).then(
        (result) => sendResponse({ ok: true, result })
      ).catch(
        (error) => sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Could not load analysis."
        })
      );
      return true;
    }
    if (message?.type === "analyze") {
      createAnalysis(message.request).then(
        (result) => sendResponse({ ok: true, result })
      ).catch(
        (error) => sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Is the ScamHelp server running?"
        })
      );
      return true;
    }
    if (message?.type === "applyPageAnnotations") {
      applyPageAnnotations(message).then((response) => sendResponse(response)).catch(
        (error) => sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Could not annotate this page."
        })
      );
      return true;
    }
    if (message?.type === "checkUrls") {
      checkUrls(message.urls).then(
        (results) => sendResponse({
          ok: true,
          results
        })
      ).catch(
        (error) => sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Is the ScamHelp server running?"
        })
      );
      return true;
    }
    return false;
  }
);
